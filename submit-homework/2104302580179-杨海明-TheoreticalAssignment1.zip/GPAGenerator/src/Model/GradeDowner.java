package Model;

import java.util.Comparator;

public class GradeDowner implements Comparator<String[]> {
//	重写排序。。。我真的想不出变量名了。。。不要怪我
	@Override
        public int compare(String[] a, String[] b)
        {
            if (Double.valueOf(a[9]) < Double.valueOf(b[9])){
                return 1;
            }
            else {
            return -1;
            }
        }
	
    }


